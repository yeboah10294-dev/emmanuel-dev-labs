
"use client"

import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, Settings, Radio, Users } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function StreamPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(80);
  const [viewerCount, setViewerCount] = useState(124);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Simulate viewer fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setViewerCount(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) videoRef.current.pause();
      else videoRef.current.play();
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="relative group w-full aspect-video bg-black rounded-xl overflow-hidden shadow-2xl border-4 border-white/10 ring-1 ring-primary/20">
      {/* Actual Video Tag - Using a placeholder high-res choir-like visual */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        poster="https://picsum.photos/seed/angelic-1/1200/675"
        src="https://www.w3schools.com/html/mov_bbb.mp4" // Placeholder stream source
        playsInline
        loop
      />

      {/* Overlay UI */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        
        {/* Top Bar */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
          <Badge className="bg-destructive hover:bg-destructive animate-pulse gap-1.5 py-1 px-3">
            <Radio className="h-3.5 w-3.5" />
            LIVE
          </Badge>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="bg-black/50 text-white backdrop-blur-md gap-1.5 border-none">
              <Users className="h-3.5 w-3.5" />
              {viewerCount}
            </Badge>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 backdrop-blur-sm">
              <Settings className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Center Play Button (Large) */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Button 
              onClick={togglePlay}
              className="w-20 h-20 rounded-full bg-primary/80 hover:bg-primary text-white backdrop-blur-md shadow-2xl transition-transform hover:scale-110"
            >
              <Play className="h-10 w-10 fill-current ml-1" />
            </Button>
          </div>
        )}

        {/* Bottom Controls */}
        <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2">
          {/* Progress Bar (Fake for live) */}
          <div className="h-1 w-full bg-white/20 rounded-full overflow-hidden">
             <div className="h-full w-full bg-primary animate-pulse shadow-[0_0_10px_rgba(77,128,204,0.8)]" />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={togglePlay}>
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
              </Button>

              <div className="flex items-center gap-2 px-2">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={toggleMute}>
                  {isMuted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </Button>
                <Slider 
                  value={[volume]} 
                  max={100} 
                  step={1} 
                  className="w-24 opacity-80 hover:opacity-100 transition-opacity"
                  onValueChange={(vals) => setVolume(vals[0])}
                />
              </div>

              <span className="text-xs text-white/80 font-medium px-2 flex items-center gap-1">
                High Fidelity Audio • 48kHz / 320kbps
              </span>
            </div>

            <Button variant="ghost" size="icon" className="text-white hover:bg-white/20">
              <Maximize className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Audio Priority Hint Overlay */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2">
        <div className="bg-primary/20 backdrop-blur-lg px-4 py-1.5 rounded-full border border-primary/30 flex items-center gap-2">
           <div className="w-1.5 h-1.5 rounded-full bg-accent animate-ping" />
           <span className="text-[10px] uppercase tracking-widest font-bold text-white shadow-sm">Optimum Audio Clarity Active</span>
        </div>
      </div>
    </div>
  );
}
