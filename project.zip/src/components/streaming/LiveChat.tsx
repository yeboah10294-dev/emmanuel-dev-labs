
"use client"

import { useState, useRef, useEffect } from "react";
import { Send, Smile, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useFirestore, useCollection, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, limit, addDoc, serverTimestamp } from "firebase/firestore";

type Message = {
  id: string;
  uid?: string;
  displayName: string;
  text: string;
  avatar?: string;
  isAdmin?: boolean;
  timestamp?: any;
};

export function LiveChat() {
  const db = useFirestore();
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const messagesQuery = useMemoFirebase(() => {
    if (!db) return null;
    return query(collection(db, "chat_messages"), orderBy("timestamp", "asc"), limit(50));
  }, [db]);

  const { data: messages, loading } = useCollection<Message>(messagesQuery);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || !db) return;

    addDoc(collection(db, "chat_messages"), {
      displayName: "You",
      text: input,
      timestamp: serverTimestamp(),
      isAdmin: false
    });
    
    setInput("");
  };

  return (
    <div className="flex flex-col h-[400px] md:h-[600px] w-full bg-card rounded-xl shadow-sm border overflow-hidden">
      <div className="p-4 border-b bg-muted/30 flex items-center justify-between">
        <h3 className="font-semibold text-sm flex items-center gap-2">
          Live Community Chat
          <span className="flex h-2 w-2 rounded-full bg-green-500 animate-pulse" />
        </h3>
      </div>
      
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {loading && (
            <div className="flex justify-center p-4">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          )}
          {!loading && messages?.map((msg) => (
            <div key={msg.id} className="flex items-start gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <Avatar className="h-8 w-8 border border-muted">
                {msg.avatar ? (
                  <AvatarImage src={msg.avatar} />
                ) : (
                  <AvatarFallback className="bg-primary/10 text-primary text-xs">
                    {msg.displayName?.[0] || "?"}
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-xs font-bold",
                    msg.isAdmin ? "text-accent" : "text-foreground"
                  )}>
                    {msg.displayName}
                  </span>
                  {msg.isAdmin && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-accent/10 text-accent font-bold uppercase">
                      Admin
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {msg.text}
                </p>
              </div>
            </div>
          ))}
          {!loading && (!messages || messages.length === 0) && (
            <p className="text-center text-xs text-muted-foreground py-8">No messages yet. Start the conversation!</p>
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t bg-muted/20">
        <div className="flex items-center gap-2">
          <Input 
            placeholder="Type your message..." 
            className="flex-1 bg-background h-10 md:h-12"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-primary hidden sm:flex">
            <Smile className="h-5 w-5" />
          </Button>
          <Button size="icon" className="bg-primary hover:bg-primary/90 text-white h-10 w-10 md:h-12 md:w-12" onClick={handleSend}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
