"use client"

import { useState, useRef, useEffect } from "react";
import { 
  Mic, MicOff, Video, VideoOff, PhoneOff, Settings, Users, 
  MessageSquare, ShieldCheck, Camera, Sparkles, MonitorUp, 
  Link as LinkIcon, Share2, MoreVertical, Radio, Youtube, 
  Search, Play, X, ExternalLink, Volume2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import Image from "next/image";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

type Participant = {
  id: string;
  name: string;
  isMe?: boolean;
  isMuted: boolean;
  isVideoOff: boolean;
  avatar: string;
  vocalRange: string;
  isTalking?: boolean;
};

const INITIAL_PARTICIPANTS: Participant[] = [
  { id: '1', name: 'Director Samuel', isMuted: false, isVideoOff: false, avatar: 'https://picsum.photos/seed/dir/200/200', vocalRange: 'Tenor', isTalking: true },
  { id: '2', name: 'Sister Grace', isMuted: true, isVideoOff: false, avatar: 'https://picsum.photos/seed/gra/200/200', vocalRange: 'Soprano' },
  { id: '3', name: 'Brother David', isMuted: false, isVideoOff: true, avatar: 'https://picsum.photos/seed/dav/200/200', vocalRange: 'Bass' },
  { id: '4', name: 'Sister Elena', isMuted: true, isVideoOff: false, avatar: 'https://picsum.photos/seed/ele/200/200', vocalRange: 'Alto' },
];

export function MeetingRoom() {
  const { toast } = useToast();
  const [isJoined, setIsJoined] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [sharingType, setSharingType] = useState<'none' | 'screen' | 'youtube'>('none');
  const [youtubeId, setYoutubeId] = useState<string | null>(null);
  const [youtubeInput, setYoutubeInput] = useState("");
  const [showYoutubeDialog, setShowYoutubeDialog] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [showStreamDialog, setShowStreamDialog] = useState(false);
  const [hasCameraPermission, setHasCameraPermission] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const setupVideoRef = useRef<HTMLVideoElement>(null);
  const [participants, setParticipants] = useState<Participant[]>(INITIAL_PARTICIPANTS);
  const MEETING_ID = "AV-CACI-LIVE";

  useEffect(() => {
    const getMedia = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        setHasCameraPermission(true);
        const targetRef = isJoined ? videoRef : setupVideoRef;
        if (targetRef.current) {
          targetRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing media:', error);
        setHasCameraPermission(false);
      }
    };
    getMedia();

    return () => {
      const currentRef = isJoined ? videoRef : setupVideoRef;
      if (currentRef.current?.srcObject) {
        const tracks = (currentRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, [isJoined]);

  const handleJoin = () => {
    setIsJoined(true);
    toast({
      title: "Joined Room",
      description: "You are now in the ANGELIC-VOICES collaboration portal.",
    });
  };

  const toggleVideo = () => {
    const currentRef = isJoined ? videoRef : setupVideoRef;
    if (currentRef.current?.srcObject) {
      const videoTrack = (currentRef.current.srcObject as MediaStream).getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !isVideoOn;
        setIsVideoOn(!isVideoOn);
      }
    }
  };

  const toggleMic = () => {
    const currentRef = isJoined ? videoRef : setupVideoRef;
    if (currentRef.current?.srcObject) {
      const audioTrack = (currentRef.current.srcObject as MediaStream).getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = isMuted; 
        setIsMuted(!isMuted);
      }
    }
  };

  const startYoutubePresentation = () => {
    if (!youtubeInput) return;
    
    // Simple regex to extract ID from youtube link
    const match = youtubeInput.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    const id = match ? match[1] : youtubeInput;

    setYoutubeId(id);
    setSharingType('youtube');
    setShowYoutubeDialog(false);
    toast({
      title: "YouTube Presentation Active",
      description: "Playing the shared track for the choir.",
    });
  };

  const stopPresentation = () => {
    setSharingType('none');
    setYoutubeId(null);
    toast({
      title: "Presentation Stopped",
      description: "Returned to the main rehearsal view.",
    });
  };

  const startStream = (platform: string) => {
    setIsStreaming(true);
    setShowStreamDialog(false);
    toast({
      title: `Live on ${platform}`,
      description: `Rehearsal is now being broadcasted to ${platform}.`,
    });
  };

  const stopStream = () => {
    setIsStreaming(false);
    toast({
      title: "Streaming Stopped",
      description: "The social media broadcast has ended.",
    });
  };

  const copyInvite = () => {
    const link = `https://angelic-voices-caci-dubai.com/join/${MEETING_ID}`;
    navigator.clipboard.writeText(link);
    toast({
      title: "Invite Link Copied!",
      description: "Meeting link ready for members.",
    });
  };

  if (!isJoined) {
    return (
      <div className="flex flex-col h-full bg-[#0a0a0c] rounded-2xl overflow-hidden border border-white/5 shadow-2xl items-center justify-center p-4 md:p-12 space-y-6 md:space-y-8 min-h-[500px]">
        <div className="text-center space-y-2">
          <h2 className="text-white text-2xl md:text-3xl font-headline font-bold">Rehearsal Entry</h2>
          <p className="text-slate-400 text-xs md:text-sm">Room ID: <span className="text-primary font-mono font-bold tracking-wider">{MEETING_ID}</span></p>
        </div>

        <div className="relative w-full max-w-2xl aspect-video rounded-2xl overflow-hidden bg-[#16161a] border border-white/10 shadow-inner group">
          <video 
            ref={setupVideoRef} 
            className={cn("w-full h-full object-cover mirror transform scale-x-[-1]", (!isVideoOn || !hasCameraPermission) && "hidden")} 
            autoPlay 
            muted 
            playsInline 
          />
          {(!isVideoOn || !hasCameraPermission) && (
            <div className="absolute inset-0 flex items-center justify-center flex-col gap-6 bg-slate-900/50 backdrop-blur-sm">
               <div className="w-16 h-16 md:w-24 md:h-24 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 border border-white/10">
                 <Camera className="h-8 w-8 md:h-10 md:w-10" />
               </div>
               <div className="text-center px-4">
                 <p className="text-white font-medium text-sm md:text-base">{!hasCameraPermission ? "Camera permission required" : "Your camera is off"}</p>
                 <p className="text-slate-400 text-[10px] md:text-xs mt-1">Check your settings before joining</p>
               </div>
            </div>
          )}
          
          <div className="absolute bottom-4 md:bottom-6 left-1/2 -translate-x-1/2 flex gap-3 md:gap-4">
            <Button 
              variant={isMuted ? "destructive" : "secondary"} 
              size="icon" 
              className="h-12 w-12 md:h-14 md:w-14 rounded-full backdrop-blur-md bg-white/10 border-white/10 hover:bg-white/20 transition-all shadow-lg"
              onClick={toggleMic}
            >
              {isMuted ? <MicOff className="h-5 w-5 md:h-6 md:w-6" /> : <Mic className="h-5 w-5 md:h-6 md:w-6" />}
            </Button>
            <Button 
              variant={!isVideoOn ? "destructive" : "secondary"} 
              size="icon" 
              className="h-12 w-12 md:h-14 md:w-14 rounded-full backdrop-blur-md bg-white/10 border-white/10 hover:bg-white/20 transition-all shadow-lg"
              onClick={toggleVideo}
            >
              {!isVideoOn ? <VideoOff className="h-5 w-5 md:h-6 md:w-6" /> : <Video className="h-5 w-5 md:h-6 md:w-6" />}
            </Button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8 w-full max-w-2xl justify-between border-t border-white/5 pt-6 md:pt-8">
          <div className="flex items-center gap-4">
            <div className="flex -space-x-3">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="w-8 h-8 md:w-10 md:h-10 rounded-full border-2 border-slate-950 bg-slate-800 overflow-hidden ring-1 ring-white/5">
                  <Image src={`https://picsum.photos/seed/setup-${i}/40/40`} alt="Member" width={40} height={40} className="object-cover" />
                </div>
              ))}
            </div>
            <p className="text-slate-400 text-xs md:text-sm">Members are active in the room</p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <Button variant="ghost" className="flex-1 md:flex-none rounded-full text-slate-300 hover:bg-white/5 h-12" onClick={copyInvite}>
              <LinkIcon className="h-4 w-4 mr-2" />
              Invite
            </Button>
            <Button size="lg" className="flex-[2] md:flex-none rounded-full px-8 md:px-12 bg-primary hover:bg-primary/90 h-12 md:h-14 text-sm md:text-lg font-bold shadow-xl shadow-primary/20" onClick={handleJoin}>
              Join Room
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#0a0a0c] rounded-2xl overflow-hidden border border-white/10 shadow-2xl relative min-h-[600px]">
      {/* Header Overlay */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4 md:p-6 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
        <div className="flex items-center gap-2 md:gap-4 pointer-events-auto">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <Badge variant="destructive" className="animate-pulse flex gap-1.5 px-2 md:px-4 py-0.5 md:py-1 font-bold tracking-tight text-[10px] md:text-xs">
                <div className="w-1.5 h-1.5 md:w-2 md:h-2 rounded-full bg-white animate-ping" />
                LIVE REHEARSAL
              </Badge>
              {isStreaming && (
                <Badge className="bg-emerald-500 animate-pulse flex gap-1.5 px-2 py-0.5 md:py-1 font-bold tracking-tight text-[10px] md:text-xs">
                  <Radio className="h-3 w-3" />
                  STREAMING
                </Badge>
              )}
            </div>
            <span className="text-white text-[10px] md:text-sm font-headline font-bold uppercase tracking-tight mt-1">ANGELIC-VOICES-CACI-DUBAI</span>
          </div>
        </div>
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-full px-3 md:px-4 py-1 md:py-1.5 flex items-center gap-1.5 md:gap-2">
            <ShieldCheck className="h-3 w-3 md:h-4 md:w-4 text-emerald-500" />
            <span className="text-white/80 text-[8px] md:text-[10px] font-bold uppercase tracking-widest hidden sm:inline">Encrypted Portal</span>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className={cn(
        "flex-1 p-4 md:p-6 grid gap-4 md:gap-6 transition-all duration-500 ease-in-out",
        sharingType !== 'none' ? "grid-cols-1 lg:grid-cols-4" : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-3"
      )}>
        {/* Presentation Area */}
        {sharingType !== 'none' ? (
          <div className="lg:col-span-3 relative rounded-2xl overflow-hidden bg-[#16161a] border-2 border-accent/40 shadow-2xl shadow-accent/10 flex flex-col items-center justify-center group min-h-[400px]">
            <div className="absolute top-4 left-4 flex gap-2 z-10">
              <Badge variant="secondary" className="bg-accent text-white border-none uppercase flex gap-2">
                {sharingType === 'screen' ? <MonitorUp className="h-3 w-3" /> : <Youtube className="h-3 w-3" />}
                {sharingType === 'screen' ? "Broadcasting Score" : "Collaborative Playback"}
              </Badge>
              <Button size="icon" variant="destructive" className="h-6 w-6 rounded-full" onClick={stopPresentation}>
                <X className="h-3 w-3" />
              </Button>
            </div>

            {sharingType === 'screen' ? (
              <div className="text-center space-y-4 md:space-y-6 animate-in fade-in zoom-in-95 duration-500 px-4">
                <div className="w-20 h-20 md:w-28 md:h-28 rounded-full bg-accent/20 flex items-center justify-center mx-auto ring-4 ring-accent/10 border border-accent/30">
                  <MonitorUp className="h-10 w-10 md:h-12 md:w-12 text-accent animate-pulse" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-white text-xl md:text-3xl font-bold font-headline">Broadcasting Score</h3>
                  <p className="text-slate-400 text-xs md:text-sm italic">"The choir is currently viewing your presentation"</p>
                </div>
              </div>
            ) : (
              <div className="w-full h-full relative">
                 <iframe 
                   className="w-full h-full aspect-video"
                   src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&controls=1&modestbranding=1&rel=0`}
                   title="YouTube Presentation"
                   allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                   allowFullScreen
                 />
                 <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between p-3 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 pointer-events-none">
                    <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center">
                          <Youtube className="h-4 w-4 text-white" />
                       </div>
                       <div className="flex flex-col">
                          <span className="text-white text-[10px] font-bold uppercase tracking-wider">Sync Playback</span>
                          <span className="text-slate-300 text-[8px]">Members are listening in real-time</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                       <Volume2 className="h-3 w-3 text-white/40" />
                       <div className="w-16 h-1 bg-white/20 rounded-full overflow-hidden">
                          <div className="h-full w-2/3 bg-red-500" />
                       </div>
                    </div>
                 </div>
              </div>
            )}
          </div>
        ) : (
          <div className="relative rounded-2xl overflow-hidden bg-[#16161a] border border-primary/40 ring-4 ring-primary/5 aspect-video group shadow-2xl transition-all hover:scale-[1.01]">
            <video 
              ref={videoRef} 
              className={cn("w-full h-full object-cover mirror transform scale-x-[-1]", !isVideoOn && "hidden")} 
              autoPlay 
              muted 
              playsInline 
            />
            {!isVideoOn && (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
                <div className="w-16 h-16 md:w-24 md:h-24 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20 animate-pulse">
                  <Users className="h-8 w-8 md:h-10 md:w-10 text-primary" />
                </div>
              </div>
            )}
            <div className="absolute bottom-3 left-3 md:bottom-4 md:left-4 flex items-center gap-2 bg-black/60 backdrop-blur-xl px-3 md:px-4 py-1.5 md:py-2 rounded-xl border border-white/10 shadow-lg">
              <span className="text-white text-[10px] md:text-xs font-bold tracking-tight">Me (You)</span>
              {isMuted && <MicOff className="h-3 w-3 text-destructive" />}
            </div>
          </div>
        )}

        {/* Participants Sidebar */}
        <div className={cn(
          "grid gap-4 transition-all duration-500",
          sharingType !== 'none' ? "flex flex-col overflow-y-auto max-h-[400px] lg:max-h-full scrollbar-hide" : "contents"
        )}>
          {participants.map((p) => (
            <div key={p.id} className={cn(
              "relative rounded-2xl overflow-hidden bg-[#16161a] border border-white/5 group aspect-video hover:border-white/20 transition-all",
              p.isTalking && "ring-2 ring-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.2)]"
            )}>
              {p.isVideoOff ? (
                <div className="absolute inset-0 flex items-center justify-center bg-slate-900">
                  <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-slate-800 flex items-center justify-center border border-white/10 overflow-hidden shadow-inner ring-2 ring-white/5">
                    <Image 
                      src={p.avatar} 
                      alt={p.name} 
                      width={100} 
                      height={100} 
                      className="object-cover"
                    />
                  </div>
                </div>
              ) : (
                <Image 
                  src={p.avatar} 
                  alt={p.name} 
                  fill 
                  className="object-cover brightness-90 group-hover:brightness-100 transition-all duration-500"
                />
              )}
              <div className="absolute bottom-3 left-3 md:bottom-4 md:left-4 flex items-center gap-2 md:gap-3 bg-black/60 backdrop-blur-xl px-3 md:px-4 py-1.5 md:py-2 rounded-xl border border-white/10">
                <span className="text-white text-[10px] md:text-xs font-semibold">{p.name}</span>
                <Badge className="bg-white/10 text-[8px] md:text-[10px] text-slate-300 border-none font-mono py-0 uppercase">{p.vocalRange}</Badge>
                {p.isMuted && <MicOff className="h-3 md:h-3.5 w-3 md:w-3.5 text-destructive" />}
                {p.isTalking && !p.isMuted && (
                  <div className="flex gap-0.5 items-end h-2 md:h-3">
                    <div className="w-0.5 md:w-1 bg-emerald-500 animate-[bounce_0.6s_infinite]" />
                    <div className="w-0.5 md:w-1 bg-emerald-500 animate-[bounce_0.8s_infinite]" />
                    <div className="w-0.5 md:w-1 bg-emerald-500 animate-[bounce_1s_infinite]" />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Control Bar */}
      <div className="bg-[#121216] border-t border-white/5 p-4 md:p-6 md:px-12 flex items-center justify-between z-30">
        <div className="flex items-center gap-6 hidden xl:flex min-w-0">
          <div className="flex flex-col min-w-0">
            <span className="text-white font-headline font-bold text-lg truncate uppercase tracking-tight">Interactive Portal</span>
            <div className="flex items-center gap-2">
               <Badge variant="outline" className="text-[9px] py-0 border-white/10 text-slate-400 font-mono tracking-widest">{MEETING_ID}</Badge>
               <span className="text-slate-500 text-[10px] uppercase font-bold tracking-widest flex items-center gap-1.5">
                 <div className="w-1 h-1 rounded-full bg-emerald-600" />
                 OPEN ACCESS
               </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-4 mx-auto md:mx-0">
          <div className="flex items-center gap-2 md:gap-3 bg-black/40 p-1 md:p-1.5 rounded-full border border-white/5">
            <Button 
              variant={isMuted ? "destructive" : "secondary"} 
              size="icon" 
              className="h-10 w-10 md:h-12 md:w-12 rounded-full transition-all active:scale-95 shadow-lg"
              onClick={toggleMic}
            >
              {isMuted ? <MicOff className="h-4 w-4 md:h-5 md:w-5" /> : <Mic className="h-4 w-4 md:h-5 md:w-5" />}
            </Button>
            <Button 
              variant={!isVideoOn ? "destructive" : "secondary"} 
              size="icon" 
              className="h-10 w-10 md:h-12 md:w-12 rounded-full transition-all active:scale-95 shadow-lg"
              onClick={toggleVideo}
            >
              {!isVideoOn ? <VideoOff className="h-4 w-4 md:h-5 md:w-5" /> : <Video className="h-4 w-4 md:h-5 md:w-5" />}
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="secondary" size="icon" className="h-10 w-10 md:h-12 md:w-12 rounded-full bg-white/5 hover:bg-white/10 text-white">
                  <MoreVertical className="h-4 w-4 md:h-5 md:w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-[#16161a] border-white/10 text-white w-72 p-2 rounded-xl">
                <DropdownMenuLabel className="text-white/40 text-[10px] uppercase font-bold">Collaborative Media</DropdownMenuLabel>
                <DropdownMenuItem className="focus:bg-white/5 cursor-pointer rounded-lg gap-3" onClick={() => setShowYoutubeDialog(true)}>
                  <Youtube className="h-4 w-4 text-red-500" />
                  Search & Play YouTube
                </DropdownMenuItem>
                <DropdownMenuItem className="focus:bg-white/5 cursor-pointer rounded-lg gap-3" onClick={() => setSharingType(sharingType === 'screen' ? 'none' : 'screen')}>
                  <MonitorUp className="h-4 w-4 text-accent" />
                  {sharingType === 'screen' ? "End Presentation" : "Present Scores"}
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-white/5" />
                <DropdownMenuLabel className="text-white/40 text-[10px] uppercase font-bold">Broadcasting</DropdownMenuLabel>
                <DropdownMenuItem className="focus:bg-white/5 cursor-pointer rounded-lg gap-3" onClick={() => setShowStreamDialog(true)}>
                  <Radio className="h-4 w-4 text-emerald-500" />
                  Live Stream Socials
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-white/5" />
                <DropdownMenuLabel className="text-white/40 text-[10px] uppercase font-bold">Tools</DropdownMenuLabel>
                <DropdownMenuItem className="focus:bg-white/5 cursor-pointer rounded-lg gap-3" onClick={copyInvite}>
                  <Share2 className="h-4 w-4" />
                  Copy Invite Link
                </DropdownMenuItem>
                <DropdownMenuItem className="focus:bg-white/5 cursor-pointer rounded-lg gap-3">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Vocal Effects
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <Button 
            variant="destructive" 
            className="h-10 md:h-12 px-4 md:px-8 rounded-full font-bold flex gap-2 md:gap-3 shadow-xl shadow-destructive/20 active:scale-95 transition-all text-xs md:text-sm" 
            onClick={() => setIsJoined(false)}
          >
            <PhoneOff className="h-4 w-4 md:h-5 md:w-5" />
            <span className="hidden sm:inline">Leave Room</span>
          </Button>
        </div>

        {/* Info Area */}
        <div className="flex items-center gap-3 hidden md:flex">
          <Button variant="ghost" size="icon" className="text-white/40 hover:text-white transition-colors relative">
            <Users className="h-5 w-5" />
            <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-primary text-[8px] font-bold flex items-center justify-center text-white ring-2 ring-[#121216]">
              {participants.length + 1}
            </div>
          </Button>
          <Button variant="ghost" size="icon" className="text-white/40 hover:text-white transition-colors">
            <MessageSquare className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* YouTube Search Dialog */}
      <Dialog open={showYoutubeDialog} onOpenChange={setShowYoutubeDialog}>
        <DialogContent className="bg-[#16161a] border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="font-headline text-2xl font-bold flex items-center gap-2">
              <Youtube className="h-6 w-6 text-red-500" />
              Collaborative YouTube
            </DialogTitle>
            <DialogDescription className="text-slate-400">
              Paste a YouTube link or search for a rehearsal track to play for everyone.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                <Input 
                  placeholder="Paste URL or search keywords..." 
                  className="pl-10 h-12 bg-white/5 border-white/10 text-white"
                  value={youtubeInput}
                  onChange={(e) => setYoutubeInput(e.target.value)}
                />
             </div>
             
             <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
                <h4 className="text-xs font-bold uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
                   <Sparkles className="h-3 w-3" />
                   Quick Actions
                </h4>
                <div className="space-y-2">
                   <Button variant="ghost" className="w-full justify-start text-[10px] h-8 hover:bg-white/5 gap-2" onClick={() => setYoutubeInput("https://www.youtube.com/watch?v=5-MT5LGE_S0")}>
                      <Play className="h-3 w-3" /> Handel's Hallelujah Chorus
                   </Button>
                   <Button variant="ghost" className="w-full justify-start text-[10px] h-8 hover:bg-white/5 gap-2" onClick={() => setYoutubeInput("https://www.youtube.com/watch?v=3M_Gg1xAJK4")}>
                      <Play className="h-3 w-3" /> CACI Dubai - Sunday Highlights
                   </Button>
                </div>
             </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" className="text-slate-400" onClick={() => setShowYoutubeDialog(false)}>
              Cancel
            </Button>
            <Button className="bg-red-600 hover:bg-red-700 text-white gap-2" onClick={startYoutubePresentation}>
              <Play className="h-4 w-4" />
              Start Playback
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Streaming Dialog */}
      <Dialog open={showStreamDialog} onOpenChange={setShowStreamDialog}>
        <DialogContent className="bg-[#16161a] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-headline text-2xl font-bold">Connect to Socials</DialogTitle>
            <DialogDescription className="text-slate-400">
              Select a platform to broadcast the ANGELIC-VOICES-CACI-DUBAI performance live.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
             {/* Mocked platforms */}
             <Button variant="outline" className="w-full justify-start gap-3 h-12 bg-white/5 border-white/10 text-white hover:bg-red-500/20" onClick={() => startStream('YouTube')}>
                <Youtube className="h-5 w-5 text-red-500" /> YouTube Live
             </Button>
             <Button variant="outline" className="w-full justify-start gap-3 h-12 bg-white/5 border-white/10 text-white hover:bg-blue-600/20" onClick={() => startStream('Facebook')}>
                <ExternalLink className="h-5 w-5 text-blue-600" /> Facebook Watch
             </Button>
          </div>
          <DialogFooter>
            <Button variant="ghost" className="text-slate-400" onClick={() => setShowStreamDialog(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
