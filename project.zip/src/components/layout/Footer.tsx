'use client';

import { useEffect, useState } from 'react';

export function Footer() {
  const [year, setYear] = useState<number | null>(null);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  return (
    <footer className="py-8 text-center text-muted-foreground border-t bg-background/50 backdrop-blur-sm mt-auto">
      <p className="font-headline text-lg italic text-primary">ANGELIC-VOICES-CACI-DUBAI</p>
      <p className="text-sm px-4">
        © {year || '...'} ANGELIC-VOICES-CACI-DUBAI. Purifying the world with song.
      </p>
    </footer>
  );
}
