"use client"

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Music, Radio, Calendar, History, User, Sparkles, Menu, PlusCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { 
  Sheet, 
  SheetContent, 
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger 
} from "@/components/ui/sheet";
import { useState } from "react";

const navItems = [
  { label: "Rehearsal", href: "/", icon: Radio },
  { label: "Schedule", href: "/events", icon: Calendar },
  { label: "Archives", href: "/archives", icon: History },
  { label: "AI Coach", href: "/coach", icon: Sparkles },
];

export function Navbar() {
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2 group min-w-0">
          <div className="p-1.5 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors shrink-0">
            <Music className="h-6 w-6 text-primary" />
          </div>
          <span className="font-headline text-base md:text-xl font-bold tracking-tight text-primary truncate">
            ANGELIC-VOICES-CACI-DUBAI
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-6 shrink-0">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary flex items-center gap-1.5",
                pathname === item.href ? "text-primary font-semibold" : "text-muted-foreground"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
          <div className="h-6 w-px bg-border mx-2" />
          <Button variant="ghost" size="sm" className="gap-2">
            <User className="h-4 w-4" />
            Login
          </Button>
          <Button size="sm" className="bg-primary hover:bg-primary/90" asChild>
            <Link href="/join">
              <PlusCircle className="h-4 w-4 mr-2" />
              Join Choir
            </Link>
          </Button>
        </div>

        {/* Mobile Nav Toggle */}
        <div className="lg:hidden">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="h-10 w-10">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] sm:w-[350px]">
              <SheetHeader className="text-left mb-6">
                <SheetTitle className="font-headline text-xl font-bold text-primary">ANGELIC-VOICES-CACI-DUBAI</SheetTitle>
                <SheetDescription className="text-[10px] text-muted-foreground tracking-widest uppercase">
                  MEMBER PORTAL
                </SheetDescription>
              </SheetHeader>
              <div className="flex flex-col gap-6">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "text-lg font-medium transition-colors hover:text-primary flex items-center gap-3",
                      pathname === item.href ? "text-primary font-semibold" : "text-muted-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.label}
                  </Link>
                ))}
                <div className="h-px bg-border my-2" />
                <Button variant="outline" className="justify-start gap-3 h-12">
                  <User className="h-5 w-5" />
                  Member Login
                </Button>
                <Button className="justify-start gap-3 bg-primary hover:bg-primary/90 h-12" asChild onClick={() => setIsOpen(false)}>
                  <Link href="/join">
                    <Music className="h-5 w-5" />
                    Join the Choir
                  </Link>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
