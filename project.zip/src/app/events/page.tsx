"use client"

import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar as CalendarIcon, Clock, MapPin, Radio, Bell, Info } from "lucide-react";
import Image from "next/image";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const UPCOMING_EVENTS = [
  {
    id: 0,
    title: "Daily Practice & Collaboration Room",
    type: "Interactive Portal",
    date: "Available Every Day",
    time: "24/7 Access",
    location: "Main Interactive Room",
    image: "https://picsum.photos/seed/practice-daily/800/400",
    isLive: true,
    isWeekly: false,
    isAlwaysOpen: true
  },
  {
    id: 1,
    title: "Saturday Full Choir Rehearsal",
    type: "Featured Rehearsal",
    date: "Every Saturday",
    time: "05:00 PM",
    location: "Main Interactive Room",
    image: "https://picsum.photos/seed/rehearsal-sat/800/400",
    isLive: false,
    isWeekly: true
  },
  {
    id: 2,
    title: "Sunday Divine Service",
    type: "Sacred Service",
    date: "Next Sunday",
    time: "09:00 AM",
    location: "Main Sanctuary",
    image: "https://picsum.photos/seed/event-1/800/400",
    isLive: false,
  },
  {
    id: 3,
    title: "Mid-Week Vesper Technicals",
    type: "Training",
    date: "Every Wednesday",
    time: "06:30 PM",
    location: "Vocal Hall",
    image: "https://picsum.photos/seed/event-2/800/400",
    isLive: false,
  }
];

export default function EventsPage() {
  return (
    <div className="container mx-auto px-4 py-12 space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div className="space-y-2 w-full md:w-auto text-center md:text-left">
          <h1 className="font-headline text-4xl md:text-5xl font-bold text-primary">ANGELIC-VOICES Schedule</h1>
          <p className="text-muted-foreground text-lg font-light">Join our interactive rooms any day, or follow our weekly featured sessions.</p>
        </div>
        <Button variant="outline" className="w-full md:w-auto gap-2 border-primary/20 text-primary">
          <Bell className="h-4 w-4" />
          Notify Me
        </Button>
      </div>

      <Alert className="bg-accent/5 border-accent/20 max-w-2xl mx-auto">
        <Info className="h-4 w-4 text-accent" />
        <AlertTitle className="text-accent font-bold">Open Portal Policy</AlertTitle>
        <AlertDescription className="text-muted-foreground">
          Members are welcome to use the **Interactive Rehearsal Room** at any time. Whether it's a planned group session or individual practice, the portal is yours to use.
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {UPCOMING_EVENTS.map((event) => (
          <Card key={event.id} className="overflow-hidden group hover:shadow-2xl transition-all duration-300 border-primary/10 bg-white">
            <div className="relative h-48 w-full overflow-hidden">
              <Image 
                src={event.image} 
                alt={event.title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-500"
                data-ai-hint="choir cathedral"
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <Badge className="bg-primary/90 backdrop-blur-sm border-none">
                  {event.type}
                </Badge>
                {event.isAlwaysOpen && (
                  <Badge variant="secondary" className="bg-emerald-500 text-white border-none">
                    Open Now
                  </Badge>
                )}
              </div>
            </div>
            <CardHeader>
              <CardTitle className="font-headline text-2xl group-hover:text-primary transition-colors">{event.title}</CardTitle>
              <CardDescription className="flex items-center gap-2">
                <CalendarIcon className="h-3.5 w-3.5 text-primary" />
                {event.date}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <div className="p-1.5 rounded-full bg-secondary">
                  <Clock className="h-4 w-4 text-primary" />
                </div>
                {event.time}
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <div className="p-1.5 rounded-full bg-secondary">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                {event.location}
              </div>
            </CardContent>
            <CardFooter className="bg-muted/30 p-4">
              <Button className="w-full gap-2 bg-primary/10 text-primary hover:bg-primary hover:text-white border-none transition-all">
                <Radio className="h-4 w-4" />
                { event.isAlwaysOpen || event.isWeekly ? "Enter Room" : "Details" }
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
