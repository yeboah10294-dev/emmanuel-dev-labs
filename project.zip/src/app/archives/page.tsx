"use client"

import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, PlayCircle, Clock, Calendar, Filter } from "lucide-react";
import Image from "next/image";

const ARCHIVES = [
  { id: 1, title: "Sunday CACI Divine Service", length: "1:24:00", date: "Jan 12, 2024", views: "1.2k", img: "https://picsum.photos/seed/archive-1/600/400" },
  { id: 2, title: "Saturday Rehearsal: Sacred Chorals", length: "45:30", date: "Jan 11, 2024", views: "840", img: "https://picsum.photos/seed/archive-2/600/400" },
  { id: 3, title: "Morning Vesper: Breath & Spirit", length: "32:15", date: "Jan 05, 2024", views: "650", img: "https://picsum.photos/seed/archive-3/600/400" },
  { id: 4, title: "Full Choir: Hallelujah Chorus 2023", length: "58:00", date: "Dec 31, 2023", views: "2.4k", img: "https://picsum.photos/seed/archive-4/600/400" },
  { id: 5, title: "Divine Service: The Light of Faith", length: "1:10:00", date: "Dec 24, 2023", views: "1.1k", img: "https://picsum.photos/seed/archive-5/600/400" },
  { id: 6, title: "Technical Workshop: Vocal Purity", length: "1:45:00", date: "Dec 15, 2023", views: "450", img: "https://picsum.photos/seed/archive-6/600/400" },
];

export default function ArchivesPage() {
  return (
    <div className="container mx-auto px-4 py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="font-headline text-5xl font-bold text-primary">CACI Dubai Archives</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto font-light">
          Relive every performance and technical rehearsal. Our complete archive of sacred harmonies, preserved for the CACI community.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 max-w-2xl mx-auto">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search archives..." className="pl-10 h-12 border-primary/20 bg-white" />
        </div>
        <Button variant="outline" className="h-12 gap-2 border-primary/20">
          <Filter className="h-4 w-4" />
          Filter Sessions
        </Button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {ARCHIVES.map((item) => (
          <Card key={item.id} className="group cursor-pointer border-none shadow-none bg-transparent">
            <CardContent className="p-0 space-y-4">
              <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg border border-primary/10">
                <Image 
                  src={item.img} 
                  alt={item.title} 
                  fill 
                  className="object-cover group-hover:scale-110 transition-transform duration-700"
                  data-ai-hint="choir archive"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <PlayCircle className="h-12 w-12 text-white" />
                </div>
                <div className="absolute bottom-3 right-3 px-2 py-1 rounded bg-black/70 text-white text-[10px] font-bold">
                  {item.length}
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="font-headline text-xl font-bold text-primary group-hover:text-accent transition-colors">
                  {item.title}
                </h3>
                <div className="flex items-center gap-4 text-xs text-muted-foreground font-light">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3 w-3" />
                    {item.date}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3 w-3" />
                    {item.views} views
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="pt-8 text-center">
        <Button variant="ghost" className="text-primary hover:text-primary/80 font-semibold">
          Load Historical Records
        </Button>
      </div>
    </div>
  );
}
