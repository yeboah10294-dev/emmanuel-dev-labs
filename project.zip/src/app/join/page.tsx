
"use client"

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Mic2, Send, CheckCircle2, Music, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useFirestore } from "@/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export default function JoinPage() {
  const { toast } = useToast();
  const db = useFirestore();
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    vocalRange: "",
    experience: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;

    setLoading(true);
    try {
      await addDoc(collection(db, "applications"), {
        ...formData,
        status: "pending",
        submittedAt: serverTimestamp()
      });

      setSubmitted(true);
      toast({
        title: "Application Received",
        description: "We've received your application. Our music director will contact you soon.",
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to submit application. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="container mx-auto px-4 py-24 flex flex-col items-center justify-center text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center">
          <CheckCircle2 className="h-10 w-10 text-emerald-600" />
        </div>
        <h1 className="font-headline text-4xl font-bold text-primary">Thank You!</h1>
        <p className="text-muted-foreground text-lg max-w-md">
          Your journey to becoming an Angelic Voice has begun. We will review your application and reach out within 3-5 business days.
        </p>
        <Button asChild className="bg-primary px-8">
          <a href="/">Return Home</a>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl space-y-12">
      <div className="text-center space-y-4">
        <h1 className="font-headline text-5xl font-bold text-primary">Join the Harmony</h1>
        <p className="text-muted-foreground text-lg font-light">
          Are you passionate about sacred music? Apply to join our international choir community.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <Card className="md:col-span-2 border-primary/10 shadow-xl">
          <CardHeader>
            <CardTitle className="font-headline text-2xl">Member Application</CardTitle>
            <CardDescription>Tell us about your musical background and voice.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input 
                    id="name" 
                    placeholder="John Doe" 
                    required 
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="john@example.com" 
                    required 
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="range">Vocal Range</Label>
                <Select required onValueChange={(val) => setFormData({...formData, vocalRange: val})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="soprano">Soprano</SelectItem>
                    <SelectItem value="alto">Alto</SelectItem>
                    <SelectItem value="tenor">Tenor</SelectItem>
                    <SelectItem value="bass">Bass</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="experience">Musical Experience</Label>
                <Textarea 
                  id="experience" 
                  placeholder="Tell us about your previous choir or solo experience..." 
                  className="min-h-[120px]"
                  required
                  value={formData.experience}
                  onChange={(e) => setFormData({...formData, experience: e.target.value})}
                />
              </div>

              <Button type="submit" className="w-full h-12 text-lg gap-2 bg-primary" disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {loading ? "Submitting..." : "Submit Application"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <div className="p-6 bg-accent/10 rounded-xl space-y-4 border border-accent/20">
            <h4 className="font-headline text-xl font-bold text-accent flex items-center gap-2">
              <Mic2 className="h-5 w-5" />
              Audition Info
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              After applying, you'll be invited to a private video session with our director for a vocal assessment.
            </p>
          </div>

          <div className="p-6 bg-secondary/50 rounded-xl space-y-4">
            <h4 className="font-headline text-xl font-bold text-primary flex items-center gap-2">
              <Music className="h-5 w-5" />
              Commitment
            </h4>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li>• Weekly Sat Evening rehearsal</li>
              <li>• Monthly full-choir workshops</li>
              <li>• Quarterly seasonal concerts</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
