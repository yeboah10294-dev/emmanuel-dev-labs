"use client"

import { MeetingRoom } from "@/components/meeting/MeetingRoom";
import { LiveChat } from "@/components/streaming/LiveChat";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Music, Mic2, MonitorUp, Info, LayoutGrid, Link as LinkIcon, Sparkles, Globe, Radio } from "lucide-react";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { toast } = useToast();

  const handleCopyLink = () => {
    navigator.clipboard.writeText("https://angelic-voices-caci-dubai.com/join/AV-CACI-LIVE");
    toast({
      title: "Invite Link Copied!",
      description: "Meeting invitation link has been copied to your clipboard.",
    });
  };

  return (
    <div className="container mx-auto px-4 py-6 md:py-8 space-y-8 md:space-y-12 overflow-x-hidden">
      {/* Hero Interactive Rehearsal Section */}
      <section className="flex flex-col lg:flex-row gap-6 md:gap-8 items-stretch">
        <div className="flex-[2] space-y-4 md:space-y-6 flex flex-col">
          <div className="space-y-2 text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start gap-2 text-primary font-bold tracking-widest text-[10px] md:text-xs uppercase">
              <Sparkles className="h-3 w-3 md:h-4 md:w-4" />
              ANGELIC-VOICES-CACI-DUBAI 24/7 Interactive Portal
            </div>
            <h1 className="font-headline text-2xl md:text-5xl font-bold text-primary leading-tight">
              Rehearse, Present & Broadcast
            </h1>
            <p className="text-muted-foreground text-sm md:text-lg max-w-2xl mx-auto lg:mx-0 font-light italic">
              Connect for professional vocal collaboration. Share scores in real-time and broadcast live to YouTube, Facebook, and Instagram.
            </p>
          </div>

          <div className="flex-1 min-h-[500px] w-full">
            <MeetingRoom />
          </div>

          <div className="flex flex-wrap gap-2 md:gap-3 justify-center lg:justify-start">
            <Button 
              variant="outline" 
              className="flex-1 sm:flex-none gap-2 bg-white/50 border-primary/20 hover:bg-white h-12 md:h-11"
              onClick={handleCopyLink}
            >
              <LinkIcon className="h-4 w-4" />
              Copy Portal Link
            </Button>
            <Button variant="outline" className="flex-1 sm:flex-none gap-2 bg-white/50 border-primary/20 hover:bg-white h-12 md:h-11">
              <Info className="h-4 w-4" />
              Session Library
            </Button>
            <Link href="/coach" className="w-full sm:w-auto">
              <Button className="w-full bg-accent hover:bg-accent/90 gap-2 h-12 md:h-11 shadow-md">
                <Mic2 className="h-4 w-4" />
                AI Vocal Coach
              </Button>
            </Link>
          </div>
        </div>

        <aside className="flex-1 flex flex-col min-h-[400px]">
          <LiveChat />
        </aside>
      </section>

      {/* Features Section */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 py-8 md:py-12 border-t">
        <Card className="border-none bg-primary/5 shadow-none group hover:bg-primary/10 transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
              <Radio className="h-6 w-6" />
            </div>
            <h3 className="font-headline text-xl md:text-2xl font-semibold text-primary">Live Broadcasting</h3>
            <p className="text-muted-foreground text-sm font-light">
              Connect your rehearsals to social media instantly. Stream live performances to your community on YouTube and Facebook.
            </p>
          </CardContent>
        </Card>

        <Card className="border-none bg-accent/5 shadow-none group hover:bg-accent/10 transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center text-accent group-hover:scale-110 transition-transform">
              <MonitorUp className="h-6 w-6" />
            </div>
            <h3 className="font-headline text-xl md:text-2xl font-semibold text-accent">Professional Sharing</h3>
            <p className="text-muted-foreground text-sm font-light">
              High-fidelity presentation mode for sheet music and scores. Collaborate with professional clarity across any device.
            </p>
          </CardContent>
        </Card>

        <Card className="sm:col-span-2 lg:col-span-1 border-none bg-secondary/50 shadow-none group hover:bg-secondary transition-colors">
          <CardContent className="pt-6 text-center space-y-4">
            <div className="mx-auto w-12 h-12 rounded-full bg-secondary-foreground/10 flex items-center justify-center text-secondary-foreground group-hover:scale-110 transition-transform">
              <Globe className="h-6 w-6" />
            </div>
            <h3 className="font-headline text-xl md:text-2xl font-semibold text-secondary-foreground">Global Collaboration</h3>
            <p className="text-muted-foreground text-sm font-light">
              An open 24/7 interactive space for choir members worldwide. Join rehearsals anytime, from any continent.
            </p>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
