"use client"

import { useState } from "react";
import { aiVocalExerciseAssistant, AIVocalExerciseAssistantOutput } from "@/ai/flows/ai-vocal-exercise-assistant-flow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Sparkles, Mic2, Loader2, PlayCircle, BookOpen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AICoachPage() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [vocalRange, setVocalRange] = useState<any>("");
  const [needs, setNeeds] = useState("");
  const [result, setResult] = useState<AIVocalExerciseAssistantOutput | null>(null);

  const handleGenerate = async () => {
    if (!vocalRange) {
      toast({
        title: "Selection Required",
        description: "Please select your vocal range first.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const output = await aiVocalExerciseAssistant({
        vocalRange: vocalRange,
        specificNeeds: needs
      });
      setResult(output);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to generate exercises. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 md:py-12 max-w-4xl space-y-8 md:space-y-12">
      <div className="text-center space-y-4">
        <div className="inline-flex p-3 rounded-full bg-accent/10 text-accent mb-2">
          <Sparkles className="h-6 w-6 md:h-8 md:w-8" />
        </div>
        <h1 className="font-headline text-3xl md:text-5xl font-bold text-primary">AI Vocal Coach</h1>
        <p className="text-muted-foreground text-base md:text-lg max-w-2xl mx-auto font-light">
          Unlock the full potential of your voice with a personalized routine designed specifically for your range and goals.
        </p>
      </div>

      <Card className="border-primary/10 shadow-xl overflow-hidden bg-white/50 backdrop-blur-sm">
        <CardHeader className="bg-primary/5 border-b pb-4 md:pb-6">
          <CardTitle className="font-headline text-xl md:text-2xl flex items-center gap-2">
            <Mic2 className="h-5 w-5 text-primary" />
            Voice Profile Settings
          </CardTitle>
          <CardDescription>Tell us about your voice to receive custom exercises.</CardDescription>
        </CardHeader>
        <CardContent className="p-4 md:p-8 space-y-6 md:space-y-8">
          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-primary/80">Vocal Range</Label>
              <Select onValueChange={setVocalRange} value={vocalRange}>
                <SelectTrigger className="h-12 border-primary/20 bg-white text-base">
                  <SelectValue placeholder="Select your range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="soprano">Soprano</SelectItem>
                  <SelectItem value="mezzo-soprano">Mezzo-Soprano</SelectItem>
                  <SelectItem value="alto">Alto</SelectItem>
                  <SelectItem value="tenor">Tenor</SelectItem>
                  <SelectItem value="baritone">Baritone</SelectItem>
                  <SelectItem value="bass">Bass</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-3">
              <Label className="text-sm font-semibold text-primary/80">Specific Needs (Optional)</Label>
              <Input 
                placeholder="e.g. breath control, range extension..." 
                className="h-12 border-primary/20 bg-white text-base"
                value={needs}
                onChange={(e) => setNeeds(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 md:p-8 pt-0 flex justify-center">
          <Button 
            size="lg" 
            className="w-full md:w-auto px-12 h-14 text-lg bg-primary hover:bg-primary/90 gap-2 shadow-lg"
            onClick={handleGenerate}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Crafting Routine...
              </>
            ) : (
              <>
                <Sparkles className="h-5 w-5" />
                Generate My Routine
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      {result && (
        <div className="grid md:grid-cols-2 gap-6 md:gap-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
          <Card className="border-accent/20 shadow-lg h-full">
            <CardHeader className="bg-accent/5 border-b">
              <CardTitle className="flex items-center gap-2 text-accent font-headline text-xl md:text-2xl">
                <PlayCircle className="h-6 w-6" />
                Warm-Up Routine
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 md:p-6">
              <ul className="space-y-4">
                {result.warmUpSuggestions.map((item, idx) => (
                  <li key={idx} className="flex gap-3 text-muted-foreground group">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-accent/10 text-accent flex items-center justify-center text-xs font-bold group-hover:bg-accent group-hover:text-white transition-colors">
                      {idx + 1}
                    </span>
                    <span className="text-sm md:text-base font-light leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="border-primary/20 shadow-lg h-full">
            <CardHeader className="bg-primary/5 border-b">
              <CardTitle className="flex items-center gap-2 text-primary font-headline text-xl md:text-2xl">
                <BookOpen className="h-6 w-6" />
                Technical Exercises
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 md:p-6">
              <ul className="space-y-4">
                {result.exerciseSuggestions.map((item, idx) => (
                  <li key={idx} className="flex gap-3 text-muted-foreground group">
                    <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold group-hover:bg-primary group-hover:text-white transition-colors">
                      {idx + 1}
                    </span>
                    <span className="text-sm md:text-base font-light leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {result.notes && (
            <div className="md:col-span-2">
              <Card className="bg-secondary/20 border-secondary shadow-sm">
                <CardContent className="p-4 md:p-6">
                  <h4 className="font-headline text-xl text-primary font-bold mb-2">Coach's Advice</h4>
                  <p className="text-sm md:text-base text-muted-foreground italic font-light leading-relaxed">
                    "{result.notes}"
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}
    </div>
  );
}