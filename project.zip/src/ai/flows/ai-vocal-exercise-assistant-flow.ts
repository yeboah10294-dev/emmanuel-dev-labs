'use server';
/**
 * @fileOverview An AI vocal coach that provides personalized warm-up and exercise suggestions.
 *
 * - aiVocalExerciseAssistant - A function that generates vocal exercise suggestions.
 * - AIVocalExerciseAssistantInput - The input type for the aiVocalExerciseAssistant function.
 * - AIVocalExerciseAssistantOutput - The return type for the aiVocalExerciseAssistant function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AIVocalExerciseAssistantInputSchema = z.object({
  vocalRange: z
    .enum(['soprano', 'mezzo-soprano', 'alto', 'tenor', 'baritone', 'bass'])
    .describe('The vocal range of the choir member (e.g., soprano, alto, tenor, bass).'),
  specificNeeds: z
    .string()
    .optional()
    .describe(
      'Any specific vocal needs or areas for improvement (e.g., breath control, tone quality, range extension).' 
    ),
});
export type AIVocalExerciseAssistantInput = z.infer<
  typeof AIVocalExerciseAssistantInputSchema
>;

const AIVocalExerciseAssistantOutputSchema = z.object({
  warmUpSuggestions: z
    .array(z.string())
    .describe('A list of vocal warm-up exercises tailored to the user.'),
  exerciseSuggestions: z
    .array(z.string())
    .describe('A list of vocal exercises for improvement tailored to the user.'),
  notes: z
    .string()
    .optional()
    .describe('Any additional notes or advice from the AI vocal coach.'),
});
export type AIVocalExerciseAssistantOutput = z.infer<
  typeof AIVocalExerciseAssistantOutputSchema
>;

export async function aiVocalExerciseAssistant(
  input: AIVocalExerciseAssistantInput
): Promise<AIVocalExerciseAssistantOutput> {
  return aiVocalExerciseAssistantFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiVocalExerciseAssistantPrompt',
  input: {schema: AIVocalExerciseAssistantInputSchema},
  output: {schema: AIVocalExerciseAssistantOutputSchema},
  prompt: `You are an AI vocal coach specializing in choir singing. Your goal is to provide a personalized vocal warm-up routine and exercise suggestions for a choir member.

Consider the user's vocal range: {{{vocalRange}}}.

{{#if specificNeeds}}
They also have the following specific vocal needs or areas for improvement: {{{specificNeeds}}}.
{{/if}}

Provide a list of 3-5 distinct vocal warm-up exercises.
Then, provide a list of 3-5 distinct vocal exercises focused on improving technique based on their needs and vocal range.
Ensure the suggestions are clear, actionable, and suitable for choir members looking to improve their vocal technique and prepare for rehearsals or performances effectively.
Include any additional notes or general advice at the end.
`,
  config: {
    safetySettings: [
      {
        category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_HATE_SPEECH',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_HARASSMENT',
        threshold: 'BLOCK_NONE',
      },
      {
        category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT',
        threshold: 'BLOCK_NONE',
      },
    ],
  },
});

const aiVocalExerciseAssistantFlow = ai.defineFlow(
  {
    name: 'aiVocalExerciseAssistantFlow',
    inputSchema: AIVocalExerciseAssistantInputSchema,
    outputSchema: AIVocalExerciseAssistantOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
