import { config } from 'dotenv';
config();

import '@/ai/flows/ai-vocal-exercise-assistant-flow.ts';